1) Android Studio (Hedgehog veya yeni) ile MyMusic klasorunu ac, Gradle sync bitsin.
2) Build > Build Bundle(s) / APK(s) > Build APK(s)
3) APK: app/build/outputs/apk/debug/app-debug.apk -> telefona at ve kur.
Indirilen sarkilar: Android/data/com.example.mymusic/files/Music
