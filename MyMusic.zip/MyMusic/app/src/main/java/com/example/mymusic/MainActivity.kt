package com.example.mymusic

import android.app.Activity
import android.app.DownloadManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {
    private data class Result(val id: String, val title: String)

    private var controller: MediaController? = null
    private var files = listOf<File>()
    private var results = listOf<Result>()
    private var searchMode = false

    private lateinit var searchRow: LinearLayout
    private lateinit var input: EditText
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var nowPlaying: TextView
    private lateinit var playBtn: Button
    private val items = mutableListOf<String>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styled(b: Button) = b.apply {
        setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#2A2A2A"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F0F0F"))
        }

        searchRow = LinearLayout(this).apply {
            setPadding(dp(12), dp(36), dp(12), dp(8)); visibility = View.GONE
        }
        input = EditText(this).apply {
            hint = "Şarkı veya sanatçı ara"; setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE); maxLines = 1; inputType = android.text.InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> search(text.toString()); true }
        }
        searchRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(styled(Button(this).apply {
            text = "Ara"; setOnClickListener { search(input.text.toString()) }
        }))
        root.addView(searchRow)

        list = ListView(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(p: Int, v: View?, parent: android.view.ViewGroup): View =
                super.getView(p, v, parent).also { (it as TextView).setTextColor(Color.WHITE) }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            if (searchMode) download(results[pos]) else play(pos)
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        // Mini oynatıcı
        val mini = LinearLayout(this).apply {
            setBackgroundColor(Color.parseColor("#1E1E1E")); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        nowPlaying = TextView(this).apply {
            text = "Çalan şarkı yok"; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        mini.addView(nowPlaying, LinearLayout.LayoutParams(0, -2, 1f))
        playBtn = styled(Button(this).apply {
            text = "▶"; setOnClickListener {
                controller?.let { if (it.isPlaying) it.pause() else it.play() }
            }
        })
        mini.addView(styled(Button(this).apply { text = "⏮"; setOnClickListener { controller?.seekToPrevious() } }))
        mini.addView(playBtn)
        mini.addView(styled(Button(this).apply { text = "⏭"; setOnClickListener { controller?.seekToNext() } }))
        root.addView(mini)

        // Alt sekmeler
        val tabs = LinearLayout(this)
        tabs.addView(styled(Button(this).apply { text = "Kitaplık"; setOnClickListener { showLibrary() } }),
            LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(styled(Button(this).apply { text = "Ara"; setOnClickListener { showSearch() } }),
            LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)

        setContentView(root)
        showLibrary()

        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            controller = future.get().also { c ->
                c.addListener(object : androidx.media3.common.Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        playBtn.text = if (isPlaying) "⏸" else "▶"
                    }
                    override fun onMediaMetadataChanged(m: MediaMetadata) {
                        nowPlaying.text = m.title ?: "Çalan şarkı yok"
                    }
                })
            }
        }, mainExecutor)
    }

    private fun musicDir(): File =
        getExternalFilesDir(Environment.DIRECTORY_MUSIC)!!.also { it.mkdirs() }

    private fun showLibrary() {
        searchMode = false; searchRow.visibility = View.GONE
        files = musicDir().listFiles { f -> f.extension.lowercase() in setOf("mp3", "m4a", "ogg", "wav", "flac") }
            ?.sortedBy { it.name } ?: emptyList()
        items.clear(); items.addAll(files.map { it.nameWithoutExtension })
        if (files.isEmpty()) items.add("Henüz şarkı yok. 'Ara' sekmesinden indir.")
        adapter.notifyDataSetChanged()
    }

    private fun showSearch() {
        searchMode = true; searchRow.visibility = View.VISIBLE
        items.clear(); items.addAll(results.map { it.title }); adapter.notifyDataSetChanged()
    }

    private fun play(index: Int) {
        val c = controller ?: return
        if (files.isEmpty()) return
        val media = files.map {
            MediaItem.Builder().setMediaId(it.name).setUri(Uri.fromFile(it))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.nameWithoutExtension).build()).build()
        }
        c.setMediaItems(media, index, 0)
        c.prepare(); c.play()
    }

    private fun search(text: String) {
        if (text.isBlank()) return
        toast("Aranıyor...")
        Thread {
            try {
                val q = URLEncoder.encode("($text) AND mediatype:audio", "UTF-8")
                val url = "https://archive.org/advancedsearch.php?q=$q&fl%5B%5D=identifier&fl%5B%5D=title&rows=30&output=json"
                val docs = JSONObject(URL(url).readText()).getJSONObject("response").getJSONArray("docs")
                val r = (0 until docs.length()).map {
                    val d = docs.getJSONObject(it)
                    Result(d.getString("identifier"), d.optString("title", d.getString("identifier")))
                }
                runOnUiThread {
                    results = r; showSearch()
                    if (r.isEmpty()) toast("Sonuç bulunamadı")
                }
            } catch (e: Exception) { runOnUiThread { toast("Hata: ${e.message}") } }
        }.start()
    }

    private fun download(r: Result) {
        toast("İndirme hazırlanıyor...")
        Thread {
            try {
                val meta = JSONObject(URL("https://archive.org/metadata/${r.id}").readText())
                val arr = meta.getJSONArray("files")
                var name: String? = null
                for (i in 0 until arr.length()) {
                    val n = arr.getJSONObject(i).getString("name")
                    if (n.endsWith(".mp3", true)) { name = n; break }
                }
                if (name == null) { runOnUiThread { toast("Bu kayıtta mp3 yok") }; return@Thread }
                val enc = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                val safe = r.title.replace(Regex("[^\\p{L}\\p{N} ._-]"), "").take(80).trim() + ".mp3"
                val req = DownloadManager.Request(Uri.parse("https://archive.org/download/${r.id}/$enc"))
                    .setTitle(r.title)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_MUSIC, safe)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                runOnUiThread { toast("İndiriliyor. Bitince Kitaplık'a bak.") }
            } catch (e: Exception) { runOnUiThread { toast("Hata: ${e.message}") } }
        }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
